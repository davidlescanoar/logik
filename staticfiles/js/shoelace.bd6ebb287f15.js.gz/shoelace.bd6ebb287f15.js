$(document).ready(function () {
    $('#body').show();

    /*
    (() => {
        const drawer = document.querySelector('.drawer-overview');
        const openButton = document.getElementById("navbarToggler");
        const closeButton = document.getElementById("closeDrawer");

        openButton.addEventListener('click', () => drawer.show());
        closeButton.addEventListener('click', () => drawer.hide());
    })();
    */
});